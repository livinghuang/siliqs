---
title: SILIQS - IoT PCB Boards
description: A collection of PCB boards for IoT projects, including main boards with communication capabilities and various peripheral boards.
---

# SILIQS - IoT PCB Project

Welcome to the SILIQS project! This repository contains a range of PCB boards designed for IoT applications. Our project includes main boards for communication and several peripheral boards to support these main boards for various user purposes.

## Main Boards

Main boards are designed for communication and include a unique identifier in their name, starting with "SQxxx," where "xxx" represents the board number. For example, SQ001 is our first main board.

## Peripheral Boards for Sensors

Peripheral boards designed for sensor applications are named starting with "SQSxxxx," where "xxxx" corresponds to the vendor and sensor chip name. For instance, SQS1080 is our board designed for the TI HDC1080 chip with an SQS interface.

## Peripheral Boards for Communication

Peripheral boards designed for communication purposes are named starting with "SQCxxx," where "xxx" indicates the communication method. For example, SQC485 is our board designed for RS485 communication.

Feel free to explore our project and the various boards we offer. Contributions and feedback are welcome!
