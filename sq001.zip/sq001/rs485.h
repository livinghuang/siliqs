#ifndef RS485_H
#define RS485_H
#include "global.h"
void rs485_init(void);
void rs485_status_handle(void);
#endif