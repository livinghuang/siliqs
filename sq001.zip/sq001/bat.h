#ifndef BAT_H
#define BAT_H
#include "global.h"
float getBatteryVoltage();
uint8_t getBatteryLevel();
#endif